﻿var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var TabManager;
(function (TabManager) {
    var TabMenuUI = (function (_super) {
        __extends(TabMenuUI, _super);
        function TabMenuUI() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        Object.defineProperty(TabMenuUI.prototype, "activeTab", {
            set: function (value) {
                this.menuListWrap.find("." + "FTM-nav-menu-wrap-list-item").removeClass("selected");
                if (value) {
                    this.menuListWrap
                        .find("." + "FTM-nav-menu-wrap-list-item" + "[data-uid=" + value.uid + "]")
                        .addClass("selected");
                }
            },
            enumerable: false,
            configurable: true
        });
        TabMenuUI.prototype.createContainer = function () {
            this.container = $("<div class='" + "FTM-nav-menu" + "'></div>");
            this.bindEvent = this.closeMenuListOnMouseDown.bind(this);
        };
        TabMenuUI.prototype.closeMenuListOnMouseDown = function (ev) {
            var $t = $(ev.target);
            if ($t.hasClass("FTM-nav-menu")
                || $t.hasClass("FTM-nav-wrap-list-item-close")
                || $t.hasClass("FTM-nav-menu-wrap")
                || $t.hasClass("FTM-nav-menu-wrap-list")
                || $t.hasClass("FTM-nav-menu-wrap-list-item")) {
                return;
            }
            this.menuListWrap.hide();
        };
        Object.defineProperty(TabMenuUI.prototype, "styleTemplateClassName", {
            get: function () {
                if (!this.target.tabStyle) {
                    return "";
                }
                return "TabManagerTabCellType-" + this.target.tabStyle.Key + "-TabItem";
            },
            enumerable: false,
            configurable: true
        });
        Object.defineProperty(TabMenuUI.prototype, "menuItemClassName", {
            get: function () {
                return "FTM-nav-menu-wrap-list-item" + " " + "FTM-f-ellipsis" + " " + this.styleTemplateClassName;
            },
            enumerable: false,
            configurable: true
        });
        TabMenuUI.prototype.createContainerEvents = function () {
            var _this = this;
            _super.prototype.createContainerEvents.call(this);
            this.target.on("TabsChange", function () {
                _this.createMenus();
            });
            this.container.on('click', function (ev) {
                if (_this.target.tabList && _this.target.tabList.length > 0) {
                    _this.menuListWrap.show();
                }
            });
            $("body").off("mousedown", this.bindEvent).on("mousedown", this.bindEvent);
        };
        TabMenuUI.prototype.createChildren = function () {
            this.menuListWrap = $("\n<div class=\"" + "FTM-nav-menu-wrap" + "\">\n    <ul class=\"" + "FTM-nav-menu-wrap-list" + "\"></ul>\n</div>");
            this.createMenus();
            this.container.append(this.menuListWrap);
        };
        TabMenuUI.prototype.createMenus = function () {
            var _a;
            var _this = this;
            var newMenus = this.target.tabList.map(function (t) {
                var tab = $("<li data-uid=\"" + t.uid + "\" class=\"" + _this.menuItemClassName + "\" style=\"border-radius:0;box-shadow:none;border:none;\"></li>")
                    .on("click", function (ev) {
                    _this.target.active(t);
                    _this.menuListWrap.hide();
                    ev.stopPropagation();
                });
                tab.text(t.displayedTitle).attr("title", t.displayedTitle);
                if (t.canBeClosed) {
                    var closeIcon = $("<i class=\"" + "FTM-nav-wrap-list-item-close" + "\"></i>").on("click", function (ev) {
                        _this.target.closeTab(t);
                        _this.menuListWrap.hide();
                    });
                    tab.append(closeIcon);
                }
                if (t === _this.target.activeTab) {
                    tab.addClass("selected");
                }
                return tab;
            });
            this.menuListWrap.find('ul').empty();
            (_a = this.menuListWrap.find('ul')).append.apply(_a, newMenus);
        };
        return TabMenuUI;
    }(TabManager.ControlUIBase));
    TabManager.TabMenuUI = TabMenuUI;
})(TabManager || (TabManager = {}));
